#include <iostream>
#include <stdlib.h>
#include <windows.h>

int main()
{
    // Variables
    int nombreJoueur {0};
    int choixDifficulte {0};
    int nombreMystere {0};
    int nombreRentre {0};
    int continuer {1};
    int MAX {0};
    const int MIN {1};
    HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
    DWORD mode = 0;

    // Début du jeu

    std::cout << "--------------Plus ou Moins++--------------" << std::endl;

    while (continuer == 1)
    {
    Joueur:
        std::cout << "Combien y'a t'il de joueur ?" << std::endl << "1. Un Joueur" << std::endl << "2. Deux Joueur" << std::endl;
        std::cin >> nombreJoueur;
        if (std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(255, '\n');
            std::cout << "Erreur, std::cin a ete vide." << " Reessaye" << std::endl;
            goto Joueur;
        }

        if (nombreJoueur == 1)
        {
        Difficulte:
            std::cout << "Choix de la difficulte:" << std::endl << "1. Normal : Le nombre maximale est 100" << std::endl << "2. Difficile : Le nombre maximale est 1000" << std::endl << "3. Extreme : Le nombre maximale est 10000" << std::endl;
            std::cin >> choixDifficulte;
            if (std::cin.fail())
            {
                std::cin.clear();
                std::cin.ignore(255, '\n');
                std::cout << "Erreur, std::cin a ete vide." << " Reessaye" << std::endl;
                goto Difficulte;
            }

            if (choixDifficulte == 1)
            {
                MAX = 100;
            }
            else if (choixDifficulte == 2)
            {
                MAX = 1000;
            }
            else if (choixDifficulte == 3)
            {
                MAX = 10000;
            }
            else
            {
                std::cout << "N'entrez que les chiffres : 1, 2 et 3" << std::endl;
                goto Difficulte;
            }
            nombreMystere = rand() % MAX + MIN;
        }
        else if (nombreJoueur == 2)
        {
        Joueur2:

            // Configuration
            GetConsoleMode(hStdin, &mode);
            SetConsoleMode(hStdin, mode & (~ENABLE_ECHO_INPUT));

            std::cout << "Le 1er joueur ecrit le nombre mystere :" << std::endl;
            std::cin >> nombreMystere;

            if (std::cin.fail())
            {
                std::cin.clear();
                std::cin.ignore(255, '\n');
                std::cout << "Erreur, std::cin a ete vide." << " Reessaye" << std::endl;
                goto Joueur2;
            }

            // Restoration  de la configuration
            SetConsoleMode(hStdin, mode);

        }
        else
        {
            std::cout << "N'entrez que les chiffres : 1 et 2" << std::endl;
            goto Joueur;
        }

        while (nombreRentre != nombreMystere)
        {
        Jeu:
            std::cout << "Quelle est le nombre mystere ?" << std::endl;
            std::cin >> nombreRentre;

            if (std::cin.fail())
            {
                std::cin.clear();
                std::cin.ignore(255, '\n');
                std::cout << "Erreur, std::cin a ete vide." << " Reessaye" << std::endl;
                goto Jeu;
            }

            if (nombreRentre < nombreMystere)
            {
                std::cout << "C'est plus" << std::endl;
            }
            else if (nombreRentre > nombreMystere)
            {
                std::cout << "C'est moins" << std::endl;
            }

        }
    continuee:
        std::cout << "Voulez vous rejouez ?" << std::endl << "Entrez 1 pour continuer, pour arretez entrez n'importe quelle autre chiffre. " << std::endl;
        std::cin >> continuer;
        if (std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(255, '\n');
            std::cout << "Erreur, std::cin a ete vide." << " Reessaye" << std::endl;
            goto continuee;
        }

    }

    return 0;
}
