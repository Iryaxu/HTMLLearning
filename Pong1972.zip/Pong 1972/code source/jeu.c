#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <SDL.h>
#include <SDL_ttf.h>
#include "jeu.h"

void jouer (SDL_Window* ecran)
{
    //Debut de la creation des Surface/Renderer/Rect/Variables
    SDL_Surface *joueur = NULL, *ennemis = NULL, *balle = NULL, *passerelle = NULL, *scoreJoueur = NULL, *scoreEnnemis = NULL, *ligne = NULL, *gagner = NULL, *perdu = NULL;
    SDL_Rect positionJoueur, positionEnnemis, positionBalle, positionLigne, vitesseBalle, positionScore1, positionScore2;
    SDL_Event event;
    SDL_Color blanc = {255, 255, 255, 255};
    TTF_Font *consolab = NULL;
    int rates = 0, score= 0, ordre, largeur = 614, hauteur = 454, continuer = 1;
    char pointeurRates[20] = "", pointeurScore[20] = "";
    //Fin de la creation des Surface/Renderer/Rect/Variables

    sprintf(pointeurRates, "%d", rates);
    sprintf(pointeurScore, "%d", score);

    //Debut de la definition des emplacements des element du jeu

        positionJoueur.x = 15;
        positionJoueur.y = 20;
        positionJoueur.h = 27;
        positionJoueur.w = 110;

        positionEnnemis.x = 600;
        positionEnnemis.y = 310;
        positionEnnemis.h = 27;
        positionEnnemis.w = 110;

        positionBalle.x = 295;
        positionBalle.y = 220;
        positionBalle.h = 26;
        positionBalle.w = 26;

        positionScore1.x = 246;
        positionScore1.y = 10;

        positionScore2.x = 352;
        positionScore2.y = 10;

        positionLigne.x = 310;
        positionLigne.y = 0;

        vitesseBalle.x = 1;
        vitesseBalle.y = 1;

    //Fin de la definition des emplacements des element du jeu

    TTF_Init();

    //Debut du chargement des element du jeu

    joueur = SDL_LoadBMP("assets/bmp/Joueur.bmp");
    ennemis = SDL_LoadBMP("assets/bmp/Joueur.bmp");
    balle = SDL_LoadBMP("assets/bmp/Balle.bmp");
    ligne = SDL_LoadBMP("assets/bmp/ligne.bmp");
    passerelle = SDL_GetWindowSurface(ecran);
    consolab = TTF_OpenFont("assets/font/consolab.ttf", 50);

    scoreJoueur = TTF_RenderText_Solid(consolab, pointeurScore, blanc);
    scoreEnnemis = TTF_RenderText_Solid(consolab, pointeurRates, blanc);


    SDL_BlitSurface(joueur, NULL, passerelle, &positionJoueur);
    SDL_BlitSurface(ennemis, NULL, passerelle, &positionEnnemis);
    SDL_BlitSurface(balle, NULL, passerelle, &positionBalle);
    SDL_BlitSurface(ligne, NULL, passerelle, &positionLigne);
    SDL_BlitSurface(scoreJoueur, NULL, passerelle, &positionScore1);
    SDL_BlitSurface(scoreEnnemis, NULL, passerelle, &positionScore2);

    SDL_UpdateWindowSurface(ecran);

    //Fin du chargement des element du jeu

    while (rates != 10||score != 10)
    {

    // Deplacement de l'ennemis

        srand(time(NULL));
        ordre = (rand() % (MAX - MIN + 1)) + MIN;

        if (ordre == 1 )
        {
            if (positionEnnemis.y > 480)
            {
                positionEnnemis.y++;
            }
            positionEnnemis.y--;
            SDL_FillRect(passerelle, NULL, SDL_MapRGB(passerelle->format, 0, 0, 0));
            SDL_BlitSurface(ennemis, NULL, passerelle, &positionEnnemis);
            SDL_BlitSurface(joueur, NULL, passerelle, &positionJoueur);
            SDL_BlitSurface(balle, NULL, passerelle, &positionBalle);
            SDL_BlitSurface(ligne, NULL, passerelle, &positionLigne);
            SDL_BlitSurface(scoreJoueur, NULL, passerelle, &positionScore1);
            SDL_BlitSurface(scoreEnnemis, NULL, passerelle, &positionScore2);
            SDL_UpdateWindowSurface(ecran);
        }
        else
        {

            if (positionEnnemis.y > 370)
            {
                positionEnnemis.y--;
            }
            positionEnnemis.y++;
            SDL_FillRect(passerelle, NULL, SDL_MapRGB(passerelle->format, 0, 0, 0));
            SDL_BlitSurface(ennemis, NULL, passerelle, &positionEnnemis);
            SDL_BlitSurface(joueur, NULL, passerelle, &positionJoueur);
            SDL_BlitSurface(balle, NULL, passerelle, &positionBalle);
            SDL_BlitSurface(ligne, NULL, passerelle, &positionLigne);
            SDL_BlitSurface(scoreJoueur, NULL, passerelle, &positionScore1);
            SDL_BlitSurface(scoreEnnemis, NULL, passerelle, &positionScore2);
            SDL_UpdateWindowSurface(ecran);
        }

        //Deplacement de la balle

        if (positionBalle.h == positionEnnemis.y - positionEnnemis.w)
        {
            vitesseBalle.x = -1;
            vitesseBalle.y = 1;
        }

        if (positionBalle.h == positionJoueur.x - positionJoueur.w)
        {
            vitesseBalle.x = 1;
            vitesseBalle.y = -1;
        }

        if (positionBalle.x > largeur)
        {
            score++;
            vitesseBalle.x = -1;
            vitesseBalle.y = -1;
        }


        if(positionBalle.x <= 0)
        {
            rates++;
            vitesseBalle.x = 1;
            vitesseBalle.y = 1;
        }

        if (positionBalle.y > hauteur)
        {
            if (ordre == 1)
            {
                vitesseBalle.y = -1;
                vitesseBalle.x = -1;
            }

            if (ordre == 2)
            {
                vitesseBalle.x = 1;
                vitesseBalle.y = -1;
            }

        }


        if (positionBalle.y <= 0)
        {
            if (ordre == 1)
            {
                vitesseBalle.y = 1;
                vitesseBalle.x = 1;
            }

            if (ordre == 2)
            {
                vitesseBalle.x = -1;
                vitesseBalle.y = 1;
            }
        }



        sprintf(pointeurRates, "%d", rates);
        sprintf(pointeurScore, "%d", score);

        scoreJoueur = TTF_RenderText_Solid(consolab, pointeurScore, blanc);
        scoreEnnemis = TTF_RenderText_Solid(consolab, pointeurRates, blanc);

        positionBalle.x = positionBalle.x + vitesseBalle.x;
        positionBalle.y = positionBalle.y + vitesseBalle.y;

        SDL_FillRect(passerelle, NULL, SDL_MapRGB(passerelle->format, 0, 0, 0));
        SDL_BlitSurface(ennemis, NULL, passerelle, &positionEnnemis);
        SDL_BlitSurface(joueur, NULL, passerelle, &positionJoueur);
        SDL_BlitSurface(balle, NULL, passerelle, &positionBalle);
        SDL_BlitSurface(ligne, NULL, passerelle, &positionLigne);
        SDL_BlitSurface(scoreJoueur, NULL, passerelle, &positionScore1);
        SDL_BlitSurface(scoreEnnemis, NULL, passerelle, &positionScore2);
        SDL_UpdateWindowSurface(ecran);

        //Deplacement du joueur
        SDL_PollEvent(&event);
        switch (event.type)
        {
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym)
                {
                    case SDLK_UP:
                        if (positionJoueur.y > 480)
                        {
                            positionJoueur.y++;
                        }
                        positionJoueur.y--;
                        SDL_FillRect(passerelle, NULL, SDL_MapRGB(passerelle->format, 0, 0, 0));
                        SDL_BlitSurface(joueur, NULL, passerelle, &positionJoueur);
                        SDL_BlitSurface(ennemis, NULL, passerelle, &positionEnnemis);
                        SDL_BlitSurface(balle, NULL, passerelle, &positionBalle);
                        SDL_BlitSurface(ligne, NULL, passerelle, &positionLigne);
                        SDL_BlitSurface(scoreJoueur, NULL, passerelle, &positionScore1);
                        SDL_BlitSurface(scoreEnnemis, NULL, passerelle, &positionScore2);
                        SDL_UpdateWindowSurface(ecran);
                        break;

                    case SDLK_DOWN:
                        if (positionJoueur.y > 370)
                        {
                            positionJoueur.y--;
                        }
                        positionJoueur.y++;
                        SDL_FillRect(passerelle, NULL, SDL_MapRGB(passerelle->format, 0, 0, 0));
                        SDL_BlitSurface(joueur, NULL, passerelle, &positionJoueur);
                        SDL_BlitSurface(ennemis, NULL, passerelle, &positionEnnemis);
                        SDL_BlitSurface(balle, NULL, passerelle, &positionBalle);
                        SDL_BlitSurface(ligne, NULL, passerelle, &positionLigne);
                        SDL_BlitSurface(scoreJoueur, NULL, passerelle, &positionScore1);
                        SDL_BlitSurface(scoreEnnemis, NULL, passerelle, &positionScore2);
                        SDL_UpdateWindowSurface(ecran);
                        break;

                        case SDLK_ESCAPE:
                            goto end;
                            break;

                }

            }

            if (score == 10)
            {
                goto fin;
            }
            if (rates == 10)
            {
                goto fin;
            }

    }

fin:
    while (continuer != 0)
    {
        if(score == 10)
        {
            gagner = SDL_LoadBMP("assets/bmp/gagner.bmp");
            SDL_FillRect(passerelle, NULL, SDL_MapRGB(passerelle->format, 0, 0, 0));
            SDL_BlitSurface(gagner, NULL, passerelle, NULL);
            SDL_UpdateWindowSurface(ecran);
            SDL_WaitEvent(&event);
            switch(event.type)
            {
                case SDL_KEYDOWN:
                    switch(event.key.keysym.sym)
                    {
                        case SDLK_ESCAPE:
                            continuer = 0;
                            break;
                    }
                    break;
            }
        }

        if(rates == 10)
        {
            perdu = SDL_LoadBMP("assets/bmp/perdu.bmp");
            SDL_FillRect(passerelle, NULL, SDL_MapRGB(passerelle->format, 0, 0, 0));
            SDL_BlitSurface(perdu, NULL, passerelle, NULL);
            SDL_UpdateWindowSurface(ecran);
            SDL_WaitEvent(&event);
            switch(event.type)
            {
                case SDL_KEYDOWN:
                    switch(event.key.keysym.sym)
                    {
                        case SDLK_ESCAPE:
                            continuer = 0;
                            break;
                    }
                    break;
            }
        }
    }

end:

        SDL_FreeSurface(passerelle);
        SDL_FreeSurface(balle);
        SDL_FreeSurface(ennemis);
        SDL_FreeSurface(joueur);
        SDL_FreeSurface(ligne);
        SDL_FreeSurface(scoreEnnemis);
        SDL_FreeSurface(scoreJoueur);
        SDL_free(ecran);
        TTF_CloseFont(consolab);
        TTF_Quit();
        exit(EXIT_SUCCESS);

}


