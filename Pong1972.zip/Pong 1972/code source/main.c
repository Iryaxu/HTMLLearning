#include <stdlib.h>
#include <stdio.h>
#include <SDL.h>
#include "jeu.h"

int main (int argc, char *argv[])
{
    SDL_Window* ecran = NULL;
    SDL_Surface* icone = NULL;
    SDL_Surface* menu = NULL;
    SDL_Surface* passerelle = NULL;
    SDL_Renderer* renderer = NULL;
    SDL_Color black = {0, 0, 0, 255};

    int continuer = 1;

    ecran = SDL_CreateWindow("Pong", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,640, 480, SDL_WINDOW_SHOWN);
    icone = SDL_LoadBMP("assets/bmp/icone.bmp");
    passerelle = SDL_GetWindowSurface(ecran);
    menu = SDL_LoadBMP("assets/bmp/Menu.bmp");
    SDL_BlitSurface(menu, NULL, passerelle, NULL);
    SDL_SetWindowIcon(ecran, icone);
    renderer = SDL_CreateRenderer(ecran, -1, SDL_RENDERER_ACCELERATED);
    SDL_SetRenderDrawColor(renderer, black.r, black.g, black.b, black.a);

    SDL_UpdateWindowSurface(ecran);

    while (continuer)
    {
        SDL_Event event;
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    case SDLK_RETURN:
                        menu = SDL_LoadBMP("assets/bmp/Fond.bmp");
                        SDL_BlitSurface(menu , NULL, passerelle, NULL);
                        SDL_UpdateWindowSurface(ecran);
                        jouer(ecran);
                        break;
                }
                break;

        }

    }

    SDL_free(ecran);

    return 0;
}
