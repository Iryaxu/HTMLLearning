#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED

#define MAX 2
#define MIN 1

void jouer(SDL_Window* ecran);

#endif // JEU_H_INCLUDED
